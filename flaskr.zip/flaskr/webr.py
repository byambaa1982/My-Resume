import functools
from flask import Flask, render_template


from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash


bp = Blueprint('webr', __name__, url_prefix='/webr')



@bp.route('/byamba', methods=('GET', 'POST'))
def byamba():
    return 'Hello, byamba....World!'